import 'package:flutter/material.dart';

const Color kirmizi = Color(0xffdc4d3f);
const Color sari = Color(0xffecbe12);
const Color yesil = Color(0xff31ab5c);
const Color mavi = Color(0xff418cf5);

const Color kAppBarColor = yesil;