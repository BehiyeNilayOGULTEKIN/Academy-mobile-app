class ProgramIcerik {


 ProgramIcerik({required this.baslangic,
  required this.bitis,required this.ders,required this.gun});


   String gun;
   String baslangic;
   String bitis;
   String ders;

}






